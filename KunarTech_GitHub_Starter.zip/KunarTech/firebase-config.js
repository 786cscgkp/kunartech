// Firebase Console > Project settings > Your apps > Web app config
// अपनी Firebase config यहाँ भरें। खाली रहने पर Public site sample data दिखाएगी।
window.FIREBASE_CONFIG = {
  apiKey: "PASTE_API_KEY",
  authDomain: "PASTE_PROJECT.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  storageBucket: "PASTE_PROJECT.appspot.com",
  messagingSenderId: "PASTE_MESSAGING_SENDER_ID",
  appId: "PASTE_APP_ID"
};
window.WHATSAPP_NUMBER = "91XXXXXXXXXX"; // country code सहित, बिना + के
