const cfg=window.FIREBASE_CONFIG;const loginPanel=document.querySelector("#login-panel"),dash=document.querySelector("#dashboard"),msg=document.querySelector("#login-msg"),adminMsg=document.querySelector("#admin-msg"),list=document.querySelector("#admin-list");
const configured=cfg&&cfg.apiKey&&!cfg.apiKey.startsWith("PASTE");
if(!configured){msg.textContent="पहले firebase-config.js में Firebase config भरें। Setup निर्देश README में हैं।"}
else{firebase.initializeApp(cfg);const auth=firebase.auth(),db=firebase.firestore();auth.onAuthStateChanged(user=>{loginPanel.classList.toggle("hidden",!!user);dash.classList.toggle("hidden",!user);if(user)load();});
document.querySelector("#login").onclick=async()=>{try{await auth.signInWithEmailAndPassword(document.querySelector("#email").value,document.querySelector("#password").value);msg.textContent="";}catch(e){msg.textContent=e.message}};
document.querySelector("#logout").onclick=()=>auth.signOut();
function load(){db.collection("services").orderBy("name").onSnapshot(s=>{list.innerHTML=s.docs.map(d=>{let x=d.data();return `<div class="admin-row"><div><b>${x.icon||"💻"} ${safe(x.name)}</b><br><small>${safe(x.category||"")} · ${safe(x.price||"")}</small></div><div><button onclick="editService('${d.id}')">Edit</button> <button class="delete" onclick="deleteService('${d.id}')">Delete</button></div></div>`}).join("")||"अभी कोई सेवा नहीं जोड़ी गई।";});}
function safe(x){return String(x??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
window.editService=async id=>{let d=await db.collection("services").doc(id).get();let x=d.data();document.querySelector("#docid").value=id;["name","category","price","icon","description"].forEach(k=>document.querySelector("#"+k).value=x[k]||"");};
window.deleteService=async id=>{if(confirm("क्या यह सेवा हटाएँ?"))await db.collection("services").doc(id).delete();};
document.querySelector("#service-form").onsubmit=async e=>{e.preventDefault();let id=document.querySelector("#docid").value;let data={name:name.value.trim(),category:category.value.trim(),price:price.value.trim(),icon:icon.value.trim(),description:description.value.trim(),updatedAt:firebase.firestore.FieldValue.serverTimestamp()};try{if(id)await db.collection("services").doc(id).update(data);else await db.collection("services").add(data);adminMsg.textContent="सेवा सेव हो गई।";e.target.reset();docid.value="";}catch(err){adminMsg.textContent=err.message;}};
document.querySelector("#clear").onclick=()=>{document.querySelector("#service-form").reset();docid.value="";};
}
