# KunarTech Digital Services Portal

Static website + Firebase-backed Admin Panel. Deployable to GitHub Pages.

## Files
- `index.html`: Public homepage
- `admin.html`: Admin login and services dashboard
- `style.css`: Responsive styling
- `app.js`: Public service listing/search
- `admin.js`: Firebase Auth and Firestore management
- `firebase-config.js`: Firebase web configuration placeholders
- `firestore.rules`: Starter Firestore security rules

## Firebase setup (required for Admin)
1. Create a Firebase project at https://console.firebase.google.com/
2. Add a Web app and copy config into `firebase-config.js`.
3. Enable **Authentication > Sign-in method > Email/Password**.
4. Create your admin user from Firebase Authentication (do not make a public signup page).
5. Create **Firestore Database**.
6. Publish `firestore.rules` in Firestore Rules.
7. Optional: add initial services manually in Firestore collection `services`. Fields: `name`, `category`, `price`, `icon`, `description`.
8. For stronger security, restrict writes to your specific admin UID. Replace `request.auth != null` in rules with `request.auth.uid == "YOUR_ADMIN_UID"` (for create/update/delete). Use your UID from Firebase Authentication.

## GitHub Pages
1. Create a GitHub repository, e.g. `kunartech`.
2. Upload all project files to the repository root.
3. Repository **Settings > Pages**: choose `Deploy from a branch`, branch `main`, folder `/ (root)`.
4. Save and wait for Pages to publish. Your public site will be available at the GitHub Pages URL.
5. Admin URL will be `/admin.html`.

## Before publishing
- Change WhatsApp number in `firebase-config.js` to your actual number.
- Add Firebase configuration.
- Add your own accurate service list, prices, contact details and disclaimer.
- Never put secret keys or service-account credentials in frontend files. Firebase web config is public; secure access with Authentication and Firestore Rules.
- This is an original starter implementation, not a copy of another site's private code.
